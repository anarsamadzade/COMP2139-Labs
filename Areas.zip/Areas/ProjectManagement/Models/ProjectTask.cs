﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebApplication2.Areas.ProjectManagement.Models;

namespace WebApplication2.Areas.ProjectManagement.Models
{
    public class ProjectTask
    {

        [Key]
        public int ProjectTaskId { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [ForeignKey("Project")]
        public int ProjectId { get; set; }

        public Project Project { get; set; }

        public string ProjectName => Project?.Name;

        public List<ProjectTask> Tasks { get; set; }


    }
}
