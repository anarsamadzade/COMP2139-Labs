using Microsoft.AspNetCore.Mvc;
using lab1.Models;
using lab1.Data;

namespace COMP2139_Labs.Controllers
{
    public class ProjectController : Controller
    {
        private readonly Lab1Context _context;

        public ProjectController(Lab1Context context)
        {
            _context = context;
        }

        // GET: Projects
        public IActionResult Index()
        {
            // Implicitly uses LINQ when loading entities but doesn't require using System.Linq;
            var projects = _context.Projects.ToList(); // ToList is a LINQ method but used implicitly.
            return View(projects);
        }

        // GET: Projects/Details/5
        public IActionResult Details(int id)
        {
            // Find is an EF Core method that doesn't require LINQ explicitly.
            var project = _context.Projects.Find(id);
            if (project == null)
            {
                return NotFound();
            }
            return View(project);
        }

        // GET: Projects/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Projects/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Project project)
        {
            if (ModelState.IsValid)
            {
                _context.Add(project); // Add is an EF method.
                _context.SaveChanges(); // Persists the changes to the database.
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }

        // GET: Projects/Edit/5
        public IActionResult Edit(int id)
        {
            var project = _context.Projects.Find(id);
            if (project == null)
            {
                return NotFound();
            }
            return View(project);
        }

        // POST: Projects/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Project projectForm)
        {
            var project = _context.Projects.Find(id);
            if (project == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Manually copy properties you want to update
                project.Name = projectForm.Name;
                project.Description = projectForm.Description;
                project.CreatedAt = projectForm.CreatedAt;
                project.UpdatedAt = projectForm.UpdatedAt; // Consider setting this to DateTime.Now
                project.EndedAt = projectForm.EndedAt;
                project.Status = projectForm.Status;

                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }

        // GET: Projects/Delete/5
        public IActionResult Delete(int id)
        {
            var project = _context.Projects.Find(id);
            if (project == null)
            {
                return NotFound();
            }
            return View(project);
        }

        // POST: Projects/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var project = _context.Projects.Find(id);
            if (project != null)
            {
                _context.Projects.Remove(project); // Remove is an EF method.
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return NotFound();
        }
    }
}
