﻿using Microsoft.AspNetCore.Mvc;
using lab1.Data;
using lab1.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;



namespace lab1.Controllers
{

    public class TasksController : Controller
    {
        private readonly AppDbContext _db;
        public TasksController(AppDbContext context)
        {
            _db = context;
        }
        public IActionResult Index(int projectId)
        {
            var tasks = _db.ProjectTasks
                           .Where(t => t.ProjectId == projectId)
                           .ToList(); // Retrieve the list of tasks without trying to access a non-existent property

            ViewBag.ProjectId = projectId; // Store projectId in ViewBag
            return View(tasks); // Pass the list of tasks to the view
        }

        public IActionResult Details(int id)
        {
            var task = _db.ProjectTasks
                                .Include(t => t.Project) // Include related project data
                                .FirstOrDefault(t => t.ProjectTaskId == id);
            if (task == null)
            {
                return NotFound();
            }
            return View(task);
        }

        [HttpGet]
        public IActionResult Create(int projectId)
        {
            var project = _db.Projects.Find(projectId);
            if (project == null)
            {
                return NotFound();
            }

            var task = new ProjectTask
            {
                ProjectId = projectId // Set the ProjectId for the new task
            };

            return View(task); // Pass the taskModel with the ProjectId set to the view
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Title", "Description", "ProjectId")] ProjectTask task)
        {
            if (ModelState.IsValid)
            {
                _db.ProjectTasks.Add(task);
                _db.SaveChanges();
                return RedirectToAction("Index", new { projectId = task.ProjectId });
            }

            // Repopulate the Projects SelectList if returning to the form
            ViewBag.Projects = new SelectList(_db.Projects, "ProjectId", "Name", task.ProjectId);
            return View(task);
        }

        public IActionResult Edit(int id)
        {
            var task = _db.ProjectTasks
                                .Include(t => t.Project) // Include related project data
                                .FirstOrDefault(t => t.ProjectTaskId == id);
            if (task == null)
            {
                return NotFound();
            }
            ViewBag.Projects = new SelectList(_db.Projects, "ProjectId", "Name", task.ProjectId);
            return View(task);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ProjectTaskId", "Title", "Description", "ProjectId")] ProjectTask task)
        {
            if (id != task.ProjectTaskId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _db.Update(task);
                _db.SaveChanges();
                return RedirectToAction(nameof(Index), new { projectId = task.ProjectId });
            }

            ViewBag.Projects = new SelectList(_db.Projects, "ProjectId", "Name", task.ProjectId);
            return View(task);
        }

        public IActionResult Delete(int id)
        {
            var task = _db.ProjectTasks
                                .Include(t => t.Project) 
                                .FirstOrDefault(t => t.ProjectTaskId == id);
            if (task == null)
            {
                return NotFound();
            }
            
            return View(task);
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int ProjectTaskId)
        {
            var task = _db.ProjectTasks.Find(ProjectTaskId);
            if (task != null)
            {
                _db.ProjectTasks.Remove(task);
                _db.SaveChanges();
                return RedirectToAction(nameof(Index), new { projectId = task.ProjectId });
            }
            return NotFound();
        }
    }
}
