using System;
using System.ComponentModel.DataAnnotations;

public class Project
{
    [Key]
    public int ProjectId { get; set; }

    [Required(ErrorMessage = "Project name is required.")]
    public string Name { get; set; }

    public string? Description { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Created At")]
    public DateTime CreatedAt { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Updated At")]
    public DateTime UpdatedAt { get; set; }

  [DataType(DataType.Date)]
[Display(Name = "Ended At")]
public DateTime? EndedAt { get; set; }


    public string? Status { get; set; }
}
