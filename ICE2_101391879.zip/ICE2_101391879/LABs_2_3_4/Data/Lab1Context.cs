using Microsoft.EntityFrameworkCore;

namespace lab1.Data
{
    public class Lab1Context : DbContext // Renamed from AppContext to Lab1Context
    {
        public Lab1Context(DbContextOptions<Lab1Context> options) : base(options)
        {
        }

        public DbSet<Project> Projects { get; set; }
    }
}
