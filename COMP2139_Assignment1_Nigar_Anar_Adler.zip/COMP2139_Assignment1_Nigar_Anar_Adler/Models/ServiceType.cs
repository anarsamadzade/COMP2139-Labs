namespace COMP2139_Assignment1_Nigar_Anar_Adler.ViewModels
{
    public enum ServiceType


    {

        Flights,
        Hotels,
        CarRentals
    }
}
