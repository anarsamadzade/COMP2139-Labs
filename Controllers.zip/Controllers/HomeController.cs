using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using ICE3_101391879.Models;

namespace ICE3_101391879.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        // Lab 5 - Search functionality for Projects or ProjectTasks
        [HttpGet]
        public IActionResult GeneralSearch(string searchType, string searchString)
        {
            switch (searchType)
            {
                case "Projects":
                    return RedirectToAction("Search", "Projects", new { area = "ProjectManagement", searchString });

                case "Tasks":
                    var taskSearchUrl = Url.Action("Search", "Task", new { area = "ProjectManagement", searchString });
                    return Redirect(taskSearchUrl);

                default:
                    return RedirectToAction(nameof(Index));
            }
        }

        // Lab 5 - Customized NotFound View based on status code
        [Route("Home/NotFound/{statusCode}")]
        public IActionResult NotFound(int statusCode)
        {
            _logger.LogWarning($"Error {statusCode}: Page not found.");
            return statusCode == 404 ? View("NotFound") : View("Error");
        }

        // Error handling with detailed error model
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
